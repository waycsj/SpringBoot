package com.example.api.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/Student")
public class StudentController {
  @GetMapping
  public String getAllStudents() {
    return "Hello, World! ==> get";
  }

  @PostMapping
  public String postAllStudents() {
    return "Hello, World! ==> post";
  }

  @PutMapping
  public String putAllStudents() {
    return "Hello, World! ==> put";
  }

  @DeleteMapping
  public String deleteAllStudents() {
    return deleteAllStudents();
  }
}