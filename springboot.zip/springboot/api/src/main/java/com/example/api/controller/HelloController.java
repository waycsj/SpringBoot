package com.example.api.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/Hello")
public class HelloController {
  @GetMapping
  public String hello(@RequestParam(required = true, defaultValue = "world") String msg) {//   /hello?msg=hello
    return "get : query parameter = " + msg; // Replace with your own HTML file path and name, e.g., "index.html" or "home.html"
  }
  @GetMapping("/{msg}")
  public String helloPathVar(@PathVariable("msg")String msg) {//   /hello/{msg}
    return "get : path variable = " + msg; // Replace with your own HTML file path and name, e.g., "index.html" or "home.html"
  }

  @PostMapping
  public String hello2(@RequestBody Person person){
    String result = "post" + person.getName() + "," + person.getAge();
    return result;
  }
/*  public String hello2(@RequestParam String name,
                       @RequestParam int age) {
    String result = "post" + name + "," + age;
    return result;
  }*/

  @PutMapping
  public String hello3(@ModelAttribute Person person) {
    return "Hello, World! ==> put " + person.getName() + "," + person.getAge(); // Replace with your own HTML file path and name, e.g., "index.html" or "home.html"
  }

  @DeleteMapping

  public String hello4() {
    return "Hello, World! ==> delete"; // Replace with your own HTML file path and name, e.g., "index.html" or "home.html"
  }
}
